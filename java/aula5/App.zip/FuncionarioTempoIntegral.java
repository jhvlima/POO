
public class FuncionarioTempoIntegral extends Funcionario {

    public FuncionarioTempoIntegral(String string, float f) {
        this.setNome(string);
        this.setSalario(f);
    }
}
