public class Arbitro extends Pessoa {
    public Arbitro(String nome)
    {
        super(nome);
    }
}
