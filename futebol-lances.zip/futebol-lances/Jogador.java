public class Jogador extends Pessoa {
    public Jogador(String nome)
    {
        super(nome);
    }
}
