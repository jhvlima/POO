public class Falta extends Lance {
    public Falta(int minuto)
    {
        super(minuto);
    }

    @Override
    public boolean isBonito() {
        return false;
    }
}
